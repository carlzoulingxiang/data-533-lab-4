from setuptools import setup, find_packages

setup(
    name='arraytools',
    version='0.1',
    packages=find_packages(exclude=['tests*']),
    license='MIT',
    description='A test python package',
	url='https://github.com/carlzoulingxiang/data-533-lab-4.git',
    author='Nelson Carl',
    author_email='czou01@student.ubc.ca'
)