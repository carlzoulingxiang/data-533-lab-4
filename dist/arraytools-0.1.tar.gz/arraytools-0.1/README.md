# Data533 Lab 4
- Students: Ling Xiang Zou (60038213), Ao Tang (64277791)
- Date: Dec 11, 2021

[![Build Status](https://app.travis-ci.com/carlzoulingxiang/data-533-lab-4.svg?branch=main)](https://app.travis-ci.com/carlzoulingxiang/data-533-lab-4)
